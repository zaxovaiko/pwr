package com.validators;

public class MyValidator {
    // need to implement class Validator
}
